/*****************************************************************************************
Program: MathTutorV2
Programmers: Benjamin Dickinson, Ian Mensah
Date: 9/28/2026
Github Repo: https://github.com/bendickinson15/MathTutorV2.0.git
Description: It is a Math tutor page for young children. It will generate random numbers.
******************************************************************************************/
#include <iostream> //required for cout and cin
#include <cstdlib>
#include <limits>
#include <ctime>
#include <sstream>
using namespace std; //sets standard namespace

//start of the main function


int main () {
    //initializing variables
    enum MathType {MT_ADD=1,MT_SUBTRACT=2,MT_MULTIPLY=3,MT_DIVIDE=4};
    MathType mathType = MT_ADD;

    string userInput = "?";
    while (userInput == "yes" || userInput == "y");
    string userName = "unknown";
    int leftNum = 0;
    int rightNum = 0;
    int userAnswer = 0;
    int correctAnswer = 0;
    int temp = 0;
    char mathSymbol = '?';
    int totalCorrect = 0;
    int totalIncorrect = 0;
    int mathLevel = 1;

        //aesthetic header
        cout <<"(*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*]" << endl;
        cout <<"                       {*} Welcome to the tower of the wizard of magical math tutoring! (V1) {*}" << endl;
        cout << R"(
,---.    ,---.   ____   ,---------. .---.  .---.    .--.      .--..-./`)  ____..--'   ____    .-------.     ______
|    \  /    | .'  __ `.\          \|   |  |_ _|    |  |_     |  |\ .-.')|        | .'  __ `. |  _ _   \   |    _ `''.
|  ,  \/  ,  |/   '  \  \`--.  ,---'|   |  ( ' )    | _( )_   |  |/ `-' \|   .-'  '/   '  \  \| ( ' )  |   | _ | ) _  \
|  |\_   /|  ||___|  /  |   |   \   |   '-(_{;}_)   |(_ o _)  |  | `-'`"`|.-'.'   /|___|  /  ||(_ o _) /   |( ''_'  ) |
|  _( )_/ |  |   _.-`   |   :_ _:   |      (_,_)    | (_,_) \ |  | .---.    /   _/    _.-`   || (_,_).' __ | . (_) `. |
| (_ o _) |  |.'   _    |   (_I_)   | _ _--.   |    |  |/    \|  | |   |  .'._( )_ .'   _    ||  |\ \  |  ||(_    ._) '
|  (_,_)  |  ||  _( )_  |  (_(=)_)  |( ' ) |   |    |  '  /\  `  | |   |.'  (_'o._)|  _( )_  ||  | \ `'   /|  (_.\.' /
|  |      |  |\ (_ o _) /   (_I_)   (_{;}_)|   |    |    /  \    | |   ||    (_,_)|\ (_ o _) /|  |  \    / |       .'
'--'      '--' '.(_,_).'    '---'   '(_,_) '---'    `---'    `---` '---'|_________| '.(_,_).' ''-'   `'-'  '-----'`

                                                                                                                                 )" << endl;
        cout <<"(*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*]" << endl;
        cout <<R"(A wise wizards words:
        (*) What's a wizard's favorite school subject? spell-gebra!
        (*) Why did the sorcerer break his calculator? He wanted to do math-a-magics in his head!
        (*) What is a witch's favorite shape? A Hex-agon!
        (*) What do you call a snake that is 3.14 feet long? A Pi-thon!)"<< endl << endl;
        cout <<"(*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*](*)[*]{*}[*]" << endl;

        //obtaining user's name
        cout <<"What is your name young apprentice?"<< endl;
        cin >>userName;

        //math question and answer
        cout <<"Ah... "<< userName << "! So you have finally found me. If you truly seek the knowledge hidden within these ancient halls, you must" << endl;
        cout <<"first prove your mind is sharp." << endl;


    mathType = static_cast<MathType> (rand() % 4 + 1);
    leftNum = rand() % 10 + 1;
    rightNum = rand() % 10 + 1;






    switch (mathType) {
        case MT_ADD:
            mathSymbol = '+';
            correctAnswer = leftNum + rightNum;
            break;
        case MT_SUBTRACT:
            mathSymbol = '-';
            if (leftNum <= rightNum) {
                temp = leftNum;
                leftNum = rightNum;
                rightNum = temp;
            }
            correctAnswer = leftNum - rightNum;
            break;
        case MT_MULTIPLY:
            mathSymbol = '*';
            correctAnswer = leftNum*rightNum;
            break;
        case MT_DIVIDE:
            mathSymbol = '/';
            correctAnswer = leftNum;
            leftNum = rightNum * leftNum;
            break;
        default:
            cout<<"Error! Invalid Math Type:"<< mathType << endl;
            cout << "Program ended with an error -1" << endl;
            cout << "Please report this error to Debbie Johnson." << endl;
    }
        cout <<"What is " << leftNum << mathSymbol << rightNum << " = ";
    while (!(cin >> userAnswer)) {
        cin.clear(); //clear the cin error flag
        //need to include the limits library to use numeric_limits
        cin.ignore(numeric_limits<streamsize>::max(),
            '\n'); // ignore the max input, up to '\n'
        cout << "\tInvalid input!" << endl;
        cout << "\tPlease enter a number: ";
    } //end of get userAnswer while loop

        if (userAnswer == correctAnswer) {

            cout << "Good job! You Got The Question Right!" << endl << endl;
            // Got the answer correct and will move on.

        }
        else {
            cout << "I'm So Disappointed In You Apprentice" << endl << endl;
            // They got it wrong so now they know
        }

    do (
        cout<< "Would like another question?"<< endl;
        cin >> userInput;
        //put all code that needs to repeat inside this
        mathType = static_cast<MathType> (rand() % 4 + 1);
  leftNum = rand() % 10 + 1;
  rightNum = rand() % 10 + 1;



//commiting stuff


  switch (mathType) {
      case MT_ADD:
          mathSymbol = '+';
          correctAnswer = leftNum + rightNum;
          break;
      case MT_SUBTRACT:
          mathSymbol = '-';
          if (leftNum <= rightNum) {
              temp = leftNum;
              leftNum = rightNum;
              rightNum = temp;
          }
          correctAnswer = leftNum - rightNum;
          break;
      case MT_MULTIPLY:
          mathSymbol = '*';
          correctAnswer = leftNum*rightNum;
          break;
      case MT_DIVIDE:
          mathSymbol = '/';
          correctAnswer = leftNum;
          leftNum = rightNum * leftNum;
          break;
      default:
          cout<<"Error! Invalid Math Type:"<< mathType << endl;
          cout << "Program ended with an error -1" << endl;
          cout << "Please report this error to Debbie Johnson." << endl;
  }
      cout <<"What is " << leftNum << mathSymbol << rightNum << " = ";
  while (!(cin >> userAnswer)) {
      cin.clear(); //clear the cin error flag
      //need to include the limits library to use numeric_limits
      cin.ignore(numeric_limits<streamsize>::max(),
          '\n'); // ignore the max input, up to '\n'
      cout << "\tInvalid input!" << endl;
      cout << "\tPlease enter a number: ";
  } //end of get userAnswer while loop
   )

  if (userAnswer == correctAnswer) {

           cout << "Good job! You Got The Question Right!" << endl << endl;
           // Got the answer correct and will move on.

       }
       else {
           cout << "I'm So Disappointed In You Apprentice" << endl << endl;
           // They got it wrong so now they know
       }
     while (userInput == "yes" || userInput == "y");
        cout <<"This is all for our program! I hope you had a fantastic time!" << endl;
        cout << "The Wizard math V2 Be Out Shortly!" << endl;
        return 0;
    }
